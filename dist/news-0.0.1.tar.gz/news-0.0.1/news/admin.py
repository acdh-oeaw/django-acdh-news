from django.contrib import admin
from .models import NewsFeed

admin.site.register(NewsFeed)
